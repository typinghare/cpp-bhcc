/**
 * @author James Chan (Zhuojian Chen)
 */

#ifndef BHCC_CPP_READDATA_H
#define BHCC_CPP_READDATA_H

#include <iostream>

int** readData(std::string filename);

#endif